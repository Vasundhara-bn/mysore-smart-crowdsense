import cv2

def detect_crowd(image_path):
    # Dummy implementation (replace with real model)
    img = cv2.imread(image_path)
    if img is None:
        return "No image found"
    h, w, _ = img.shape
    density = "High" if h*w > 500000 else "Low"
    return f"Crowd Density: {density}"

if __name__ == "__main__":
    print(detect_crowd("data/crowd_images/sample.jpg"))
