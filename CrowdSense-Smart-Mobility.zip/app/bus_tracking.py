import json
import time

def get_bus_location():
    with open('data/sample_gps.json') as f:
        gps_data = json.load(f)
    for location in gps_data['bus_locations']:
        print(f"Bus {location['bus_id']} at {location['lat']}, {location['lon']}")
        time.sleep(1)

if __name__ == "__main__":
    get_bus_location()
