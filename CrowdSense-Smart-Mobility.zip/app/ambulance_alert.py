import time

def ambulance_alert():
    print("🚑 Ambulance detected!")
    print("🔴 Switching traffic signals to GREEN for ambulance path...")
    time.sleep(2)
    print("✅ Path cleared successfully!")

if __name__ == "__main__":
    ambulance_alert()
