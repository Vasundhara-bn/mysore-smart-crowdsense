# Crowd Sense: Smart Traffic & Emergency Solution for Mysore Dasara

## Overview
Crowd Sense is an AI-powered smart mobility and emergency response system designed to handle heavy crowds, congested public transport, 
and delayed emergency response during the Mysore Dasara festival. 

This project demonstrates a prototype system using **Flask**, **AI/ML**, and **IoT simulations**.

## Features
- 🚍 Real-time bus tracking (simulated with GPS data)
- 👥 AI-based crowd detection (using OpenCV)
- 🚑 Smart ambulance alert & IoT-based traffic signal simulation
- 📊 Centralized dashboard for live monitoring

## Project Structure
```
CrowdSense-Smart-Mobility/
│── README.md                  → Project overview & setup guide
│── requirements.txt           → Python dependencies
│── app/  
│   ├── main.py                → Flask app for dashboard  
│   ├── bus_tracking.py        → Simulated real-time bus tracking  
│   ├── crowd_detection.py     → AI-based crowd detection using OpenCV  
│   ├── ambulance_alert.py     → IoT-based ambulance priority simulation  
│   ├── static/                → CSS + JS for dashboard styling  
│   └── templates/             → HTML files for dashboard UI  
│── data/  
│   ├── sample_gps.json        → Demo bus coordinates  
│   └── crowd_images/          → Test images for AI detection  
│── docs/  
│   ├── system_architecture.png  → Block diagram  
│   └── project_report.pdf       → Final report  
```

## How to Run
1. Install dependencies:  
   ```bash
   pip install -r requirements.txt
   ```
2. Run the Flask server:  
   ```bash
   python app/main.py
   ```
3. Open in browser: `http://127.0.0.1:5000`

## Tech Stack
- Python (Flask, OpenCV, Pandas)
- AI/ML for crowd analysis
- IoT simulation for emergency response
- HTML/CSS/JS for dashboard UI

## Future Scope
- Integration with live Mysore traffic data
- Smart parking & multilingual app support
- Expansion to other public festivals

---
👩‍💻 Hackathon Project by **SafeMysuru Mobility Team**
